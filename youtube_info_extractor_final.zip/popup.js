document.getElementById('copyInfo').addEventListener('click', async () => {
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: getYouTubeInfo
  });
});

function getYouTubeInfo() {
  try {
    const title = document.querySelector('h1.title')?.innerText || 'N/A';
    const channel = document.querySelector('#text-container.ytd-channel-name')?.innerText || 'N/A';
    const views = document.querySelector('.view-count')?.innerText || 'N/A';
    const date = document.querySelector('#info-strings yt-formatted-string')?.innerText || 'N/A';
    const runtime = document.querySelector('span.ytp-time-duration')?.innerText || 'N/A';
    const comments = document.querySelectorAll('#count > yt-formatted-string')[1]?.innerText || 'N/A';

    const output = `📺 Title: ${title}\n📣 Channel: ${channel}\n👁️ Views: ${views}\n📅 Published: ${date}\n⏱️ Duration: ${runtime}\n💬 Comments: ${comments}`;

    navigator.clipboard.writeText(output).then(() => {
      alert("YouTube info copied to clipboard!");
    }).catch(() => {
      // Fallback
      const textarea = document.createElement("textarea");
      textarea.value = output;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
      alert("YouTube info copied using fallback method.");
    });
  } catch (e) {
    alert("Something went wrong: " + e.message);
  }
}